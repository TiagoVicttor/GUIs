#ifndef PEDINTE_H 
#define PEDINTE_H
#define RECUO_PEDINTE 100

#include <SDL2/SDL.h>

//-----------------Enums------------------

enum EstadoInimigo{ 
	INIMIGO_PARADO, 
	INIMIGO_LEVANTANDO, 
	INIMIGO_ANDANDO, 
	INIMIGO_PATRULHANDO,
	//INIMIGO_ATACANDO,
};

enum Direcao{ ESQUERDA = -1, DIREITA = 1 };

//---------------Struct---------------------------

typedef struct {
    SDL_Rect pos;           // posição e tamanho do sprite no mundo
    SDL_Rect frames;     // região da spritesheet
    enum Direcao dir;
    enum EstadoInimigo estado;

    Uint32 ultimoFrame;
    int frameAtual;
    int intervaloFrame;

    int distanciaVisao;
    int limiteEsq, limiteDir;  // área de patrulha
    
    int vidaPedinte;
    int ativo;
    int yBase;
} Pedinte;

//funções

void initPedinte(Pedinte* p, int x, int y, int w, int h);
void updatePedinte(Pedinte* p, SDL_Rect playerRect, Uint32 agora);
void renderPedinte(SDL_Renderer* ren, SDL_Texture* tex, Pedinte* p, SDL_Rect camera);


#endif