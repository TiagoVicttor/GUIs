#include "player.h"
#include <SDL2/SDL.h>

void initPlayer(Player* p, int x, int y, int w, int h){
	p->pos = (SDL_Rect){x,y,w,h};
	p->frames = (SDL_Rect){0,0,230,210};
	p->vely = 0;
	p->gravidade = 1;
	p->puloInicial = -18;
	p->noChao = 1;
	p->dirPlayer = DIREITA;
	p->virando = 0;
	p->frameVirada = 0;
	p->frameID = 0;
	p->frameIE = 0;
	p->ultimoFrameTroca = 0;
	p->intervaloFrame = 120;
	p->movendo = 0;
	p->playerAtacando = 0;
	p->tempoAtaque = 0.0f;
	p->duracaoAtaque = 0.25f;
	p->playerDano = 1;
	p->atacando = 0;
    p->duracaoHitbox = 300;
    p->intervaloEntreAtaques = 800;
    p->hitboxPlayer = {0,0,0,0};
    p->frameAtaque = 0;
    p->intervaloFrameAtaque = 100;
    p->ultimoFrameAtaque = 0;
    p->totalFramesAtaque = 4;
	p->puloPlayer = {0,0,0,0};
	p->pulando = 0;
    p->framePulo = 0;
    p->ultimoFramePulo = 0;
    p->intervaloFramePulo = 200;
    p->totalFramesPulo = 4;
}

/* ---------------- MOVIMENTO ---------------- */
void moverPlayer(Player *p, const Uint8 *keys, Uint32 agora) {
	if (keys[SDL_SCANCODE_LEFT]) {
        movendo = 1;
        if (dirPlayer == DIREITA && virando != 1) {
            virando = 1; frameVirada = 0; ultimoFrameTroca = agora;
        }
        if (atual != 0 || player.x > 55) player.x -= 13;
        dirPlayer = ESQUERDA;
        if (virando == 0 && !atacando) {
            if (agora - ultimoFrameTroca > intervaloFrame) {
                ultimoFrameTroca = agora;
                frameIE++;
                if (frameIE > 3) frameIE = 0;
            }
            f = (SDL_Rect){230 * frameIE, 210 * 2, 230, 210};
        }
    }
    // direita
    else if (keys[SDL_SCANCODE_RIGHT]) {
        movendo = 1;
        if (dirPlayer == ESQUERDA && virando != 2) {
            virando = 2; frameVirada = 0; ultimoFrameTroca = agora;
        }
        player.x += 13;
        dirPlayer = DIREITA;
        if (virando == 0 && !atacando) {
            if (agora - ultimoFrameTroca > intervaloFrame) {
                ultimoFrameTroca = agora;
                frameID++;
                if (frameID > 3) frameID = 0;
            }
            f = (SDL_Rect){230 * frameID, 0, 230, 210};
        }
    }
}

void puloPlayer(Player *p, const Uint8 *keys, Uint32 agora){
	if (keys[SDL_SCANCODE_Z] && noChao) {
    	if (!pulando){
    		vely = puloInicial;
            noChao = 0;
            pulando = 1;
            tempoPulo = agora;
            framePulo = 0;
            ultimoFramePulo = tempoPulo;
		}
	}
	
	if (pulando) {
        if (agora - ultimoFramePulo > intervaloFramePulo) {
            ultimoFramePulo = agora;
            framePulo++;
            if (framePulo >= totalFramesPulo) pulando = 0;
        }
        int linhaPulo = (dirPlayer == DIREITA) ? 4 : 5; // supondo linhas 4/5
        f = (SDL_Rect){230 * (framePulo % totalFramesPulo), 210 * linhaPulo, 230, 210};
	}
}

void ataquePlayer(Player *p, const Uint8 *keys, Uint32 agora){
	if (keys[SDL_SCANCODE_X]) {
        if (!atacando && agora - tempoAtaque > intervaloEntreAtaques && vidas > 0) {
            atacando = 1;
            tempoAtaque = agora;
            frameAtaque = 0;
            ultimoFrameAtaque = tempoAtaque;
        }
    }

    if (atacando) {
        if (agora - ultimoFrameAtaque > intervaloFrameAtaque) {
            ultimoFrameAtaque = agora;
            frameAtaque++;
            if (frameAtaque >= totalFramesAtaque) atacando = 0;
        }
        // hitbox depende da direção
        if (dirPlayer == DIREITA)
            hitboxPlayer = (SDL_Rect){player.x + player.w, player.y + 30, 60, 40};
        else{
        	hitboxPlayer = (SDL_Rect){player.x - 60, player.y + 30, 60, 40};
		}
        int linhaAtaque = (dirPlayer == DIREITA) ? 4 : 5; // supondo linhas 4/5
        f = (SDL_Rect){230 * (frameAtaque % totalFramesAtaque), 210 * linhaAtaque, 230, 210};
    } else {
        hitboxPlayer = (SDL_Rect){0,0,0,0};
    }
}