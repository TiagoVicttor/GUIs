#ifndef PLAYER_H
#define PLAYER_H

#include <SDL2/SDL.h>
#include "pedinte.h"

typedef struct {
	//animação player
	SDL_Rect pos;
	SDL_Rect frames;
    int vely, gravidade, puloInicial, noChao;
    enum Direcao dirPlayer;
    int virando, frameVirada, frameID, frameIE;
    Uint32 ultimoFrameTroca;
    int intervaloFrame;
    int movendo;
	
	// ataque player
	int playerAtacando;
	float tempoAtaque;
	float duracaoAtaque;
	int playerDano;
    int atacando;
    Uint32 duracaoHitbox;
    Uint32 intervaloEntreAtaques;
    SDL_Rect hitboxPlayer;
    int frameAtaque;
    int intervaloFrameAtaque;
    Uint32 ultimoFrameAtaque;
    int totalFramesAtaque;
    
    //pulo player
	SDL_Rect puloPlayer;
	int pulando;
    int framePulo;
    Uint32 ultimoFramePulo;
    int intervaloFramePulo;
    int totalFramesPulo;
} Player;

void moverPlayer(Player *p, const Uint8 *keys, Uint32 agora);
void puloPlayer(Player *p, const Uint8 *keys, Uint32 agora);
void ataquePlayer(Player *p, const Uint8 *keys, Uint32 agora);


#endif