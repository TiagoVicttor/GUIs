#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <assert.h>
#include <math.h>

/* -----------------------------------------------------------
   ESTRUTURAS E ENUMS
----------------------------------------------------------- */
enum Direcao { ESQUERDA = -1, DIREITA = 1 };

enum EstadoInimigo {INIMIGO_PARADO, INIMIGO_LEVANTANDO, INIMIGO_ANDANDO, INIMIGO_PATRULHANDO, INIMIGO_ATACANDO};

enum EstadoVida {COM_VIDA, SEM_VIDA};

/* -----------------------------------------------------------
   FUNÇÃO PRINCIPAL
----------------------------------------------------------- */
int main(int argc, char* args[]){
	
    /* INICIALIZAÇÃO SDL */
    SDL_Init(SDL_INIT_EVERYTHING);
    IMG_Init(IMG_INIT_PNG);

    SDL_Window* win = SDL_CreateWindow("Game v0.2",
        SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
        0, 0, SDL_WINDOW_FULLSCREEN_DESKTOP);

    SDL_Renderer* ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED);

    /* TEXTURAS */
    SDL_Texture* texPlayer = IMG_LoadTexture(ren, "ss.png");
    SDL_Texture* texPedinte = IMG_LoadTexture(ren, "ss pedinte.png");
    SDL_Texture* texPonte = IMG_LoadTexture(ren, "ponte.png");
    SDL_Texture* texFundo = IMG_LoadTexture(ren, "bg+lua.png");
    SDL_Texture* texHud = IMG_LoadTexture(ren, "hud.png");
    SDL_Texture* texParaFundo = IMG_LoadTexture(ren, "paralax fundo.png");
    SDL_Texture* texParaFrente = IMG_LoadTexture(ren, "paralax frente.png");
    SDL_Texture* texFlor = IMG_LoadTexture(ren, "ss flor.png");

    assert(texFlor && texPlayer && texPedinte && texPonte && texFundo && texHud && texParaFundo && texParaFrente);

    /* TELA */
    int w, h;
    SDL_GetWindowSize(win, &w, &h);
    printf("largura: %d, altura: %d\n", w, h);

    SDL_EventState(SDL_MOUSEMOTION, SDL_IGNORE);
    SDL_EventState(SDL_MOUSEBUTTONDOWN, SDL_IGNORE);
    SDL_EventState(SDL_MOUSEBUTTONUP, SDL_IGNORE);

    /* RETÂNGULOS PRINCIPAIS */
    SDL_Rect mapa = { 0, 0 , w, h };
    SDL_Rect parafun = { 0, 0 , w, h };
    SDL_Rect parafre = { 0, 0 , w, h };
    SDL_Rect vida = { 0, 0 , 510, 85 };
    SDL_Rect flor = { 15, 65 , 60, 60 };

    SDL_Rect player = { w/5, (h - ((15*h)/100)/3) - 100 +5, 110, 100 };
    SDL_Rect pedinte = { 3*w/5, (h - ((15*h)/100)/3) - 100 +5, 110, 100 };
    SDL_Rect ponteR = { 0, h - ((15*h)/100), w, (15*h)/100 };
    SDL_Rect chaoR = { 0, (h - ((15*h)/100)/3)+5, w, ((15*h)/100)/3 };

	// ANIMAÇÃO FLOR
	SDL_Rect fFlor = {0,0,280,210};
	int vidas = 3;
	int animandoFlor = -1;             // Índice da flor sendo animada (0,1,2)
	int frameFlorMorrendo = 0;         // Frame atual da animação de “sumir”
	Uint32 ultimoFrameFlor = 0;
	int intervaloFrameFlor = 120;      // Tempo entre frames da animação
	int totalFramesFlor = 13;           // Quantos frames tem a animação de sumir
	int florAltura = 210;              // altura de um frame (para facilitar)


    /* ANIMAÇÃO PLAYER */
    SDL_Rect f = { 0, 0, 230, 210 };
    int vely = 0, gravidade = 1, puloInicial = -18, noChao = 1;
    enum Direcao dirPlayer = DIREITA;
    int virando = 0, frameVirada = 0, frameID = 0, frameIE = 0;
    Uint32 ultimoFrameTroca = 0;
    int intervaloFrame = 120;

    /* PLATAFORMAS */
    int numPlataformas = 2;
    SDL_Rect plataformas[2] = {
        { 200, h - 200, 150, 20 },
        { 400, h - 300, 150, 20 },
    };

    /* PEDINTE (NPC) */
    SDL_Rect fPedinte = { 0, 0, 230, 210 };
    enum EstadoInimigo estadoPedinte = INIMIGO_PARADO;
    enum Direcao dirPedinte = ESQUERDA;
    Uint32 ultimoFramePedinte = 0;
    int framePedinte = 0;
    int intervaloFramePedinte = 300;
    int distanciaVisao = 400;
    
    int atacando = 0;                   // 1 quando a hitbox estiver ativa
	Uint32 tempoAtaque = 0;             // tempo do último ataque
	Uint32 duracaoHitbox = 300;         // ms que a hitbox fica ativa
	Uint32 intervaloEntreAtaques = 1200; // intervalo mínimo entre ataques
	SDL_Rect hitboxPedinte;             // retângulo da hitbox de ataque


    // Limites da patrulha (em torno da posição inicial)
    int limiteEsq = pedinte.x - 150;
    int limiteDir = pedinte.x + 150;
    
    


    /* LOOP PRINCIPAL */
    int espera = 16;
    while (!SDL_QuitRequested()) {

        /* ----------- RENDERIZAÇÃO ----------- */
        SDL_RenderCopy(ren, texFundo, NULL, &mapa);
        SDL_RenderCopy(ren, texParaFundo, NULL, &parafun);
        SDL_RenderCopy(ren, texParaFrente, NULL, &parafre);
        SDL_RenderCopy(ren, texHud, NULL, &vida);
        
		//Animação flor
		for (int i = 0; i < 3; i++) {
		    SDL_Rect florPos = { 15 + i * 70, 65, 60, 60 };
		    SDL_Rect frame;
		
		    if (i < vidas) {
		        // Flor normal (linha 0)
		        frame = (SDL_Rect){0, 0, 280, florAltura};
		    } 
		    else if (i == animandoFlor) {
		        // Flor “morrendo”
		        
		        frame = (SDL_Rect){280 * frameFlorMorrendo, 0, 280, florAltura};
		    } 
		    else {
		        // Flor já sumida
		        continue;
		    }
		
		    SDL_RenderCopy(ren, texFlor, &frame, &florPos);
		}



        for (int i = 0; i < numPlataformas; i++) {
            SDL_SetRenderDrawColor(ren, 0x80, 0x80, 0x80, 0xFF);
            SDL_RenderFillRect(ren, &plataformas[i]);
        }

        SDL_RenderCopy(ren, texPedinte, &fPedinte, &pedinte);
        SDL_RenderCopy(ren, texPlayer, &f, &player);
        SDL_RenderCopy(ren, texPonte, NULL, &ponteR);
        
        // DEBUG VISUAL: desenhar a hitbox do ataque
		if (atacando) {
    		SDL_RenderFillRect(ren, &hitboxPedinte);

		    // Detecta colisão com o player
		    if (SDL_HasIntersection(&hitboxPedinte, &player)) {
			    static Uint32 ultimoDano = 0;
			    Uint32 agora = SDL_GetTicks();
			
			    if (agora - ultimoDano > 1000 && vidas > 0 && animandoFlor < 0) {
			        ultimoDano = agora;
			        animandoFlor = vidas - 1;  // anima a flor da direita
			        frameFlorMorrendo = 0;
			        ultimoFrameFlor = agora;
			        printf("💥 O jogador foi atingido! Flor %d murchando...\n", animandoFlor);
			    }
			}

		}

        SDL_RenderPresent(ren);

        /* ----------- EVENTOS ----------- */
        SDL_Event evt;
        int isevt = SDL_WaitEventTimeout(&evt, espera);
        if (isevt && evt.type == SDL_QUIT) break;

        const Uint8 *keys = SDL_GetKeyboardState(NULL);
        Uint32 agora = SDL_GetTicks();
        int movendo = 0;
        
        // Atualiza animação de flor morrendo
		if (animandoFlor >= 0) {
		    if (agora - ultimoFrameFlor > intervaloFrameFlor) {
		        ultimoFrameFlor = agora;
		        frameFlorMorrendo++;
		        if (frameFlorMorrendo >= totalFramesFlor) {
		            // Animação terminou: reduz vidas e reseta controle
		            vidas--;
		            animandoFlor = -1;
		            frameFlorMorrendo = 0;
		        }
		    }
		}

        if (atacando && agora - tempoAtaque > duracaoHitbox) {
    		atacando = 0;
		}	

        /* MOVIMENTO PLAYER */
        if (keys[SDL_SCANCODE_LEFT]) {
            movendo = 1;
            if (dirPlayer == DIREITA && !virando) { virando = 1; frameVirada = 0; ultimoFrameTroca = agora; }
            player.x -= 13;
            if (virando == 1) {
                if (agora - ultimoFrameTroca > intervaloFrame) {
                    ultimoFrameTroca = agora;
                    frameVirada++;
                    if (frameVirada > 2) { virando = 0; frameIE = 0; dirPlayer = ESQUERDA; f = (SDL_Rect){0, 210*2, 230, 210}; }
                }
                f = (SDL_Rect){230 * frameVirada, 210 * 1, 230, 210};
            } else {
                dirPlayer = ESQUERDA;
                if (agora - ultimoFrameTroca > intervaloFrame) {
                    ultimoFrameTroca = agora; frameIE++;
                    if (frameIE > 3) frameIE = 0;
                }
                f = (SDL_Rect){230 * frameIE, 210 * 2, 230, 210};
            }
        }

        if (keys[SDL_SCANCODE_RIGHT]) {
            movendo = 1;
            if (dirPlayer == ESQUERDA && !virando) { virando = 2; frameVirada = 0; ultimoFrameTroca = agora; }
            player.x += 13;
            if (virando == 2) {
                if (agora - ultimoFrameTroca > intervaloFrame) {
                    ultimoFrameTroca = agora;
                    frameVirada++;
                    if (frameVirada > 2) { virando = 0; frameID = 0; dirPlayer = DIREITA; f = (SDL_Rect){0, 0, 230, 210}; }
                }
                f = (SDL_Rect){230 * frameVirada, 210 * 3, 230, 210};
            } else {
                dirPlayer = DIREITA;
                if (agora - ultimoFrameTroca > intervaloFrame) {
                    ultimoFrameTroca = agora; frameID++;
                    if (frameID > 3) frameID = 0;
                }
                f = (SDL_Rect){230 * frameID, 210 * 0, 230, 210};
            }
        }

        if (keys[SDL_SCANCODE_Z] && noChao) {
            vely = puloInicial;
            noChao = 0;
        }

        if (!movendo && !virando) {
            if (dirPlayer == DIREITA) f = (SDL_Rect){0, 0, 230, 210};
            else f = (SDL_Rect){0, 210*2, 230, 210};
        }

        /* ----------- GRAVIDADE E COLISÃO ----------- */
        player.y += vely;
        vely += gravidade;
        noChao = 0;

        if (player.y + player.h >= chaoR.y) {
            player.y = chaoR.y - player.h; vely = 0; noChao = 1;
        }

        for (int i = 0; i < numPlataformas; i++) {
            SDL_Rect plat = plataformas[i];
            if (vely >= 0 && player.y + player.h > plat.y && player.y + player.h - vely <= plat.y &&
                player.x + player.w > plat.x && player.x < plat.x + plat.w)
            {
                player.y = plat.y - player.h;
                vely = 0;
                noChao = 1;
            }
        }

        /* ----------- INTELIGÊNCIA DO PEDINTE ----------- */

		float distancia = fabs((player.x + player.w/2) - (pedinte.x + pedinte.w/2));
		
		// Se estiver perto o suficiente, inicia ataque
		if (distancia < 120 && estadoPedinte == INIMIGO_ANDANDO) {
	    	if (agora - tempoAtaque > intervaloEntreAtaques) {
	        	estadoPedinte = INIMIGO_ATACANDO;
	        	tempoAtaque = agora;
	        	atacando = 1;
	    	}
		}

		
		switch (estadoPedinte) {
		    case INIMIGO_PARADO:
		        // Fica totalmente parado até ver o jogador pela primeira vez
		        if (distancia < distanciaVisao)
		            estadoPedinte = INIMIGO_LEVANTANDO;
		        break;
		
		    case INIMIGO_LEVANTANDO:
		        // Controle da transição está na animação
		        break;
		
		    case INIMIGO_ANDANDO:
		        // Perdeu o jogador de vista -> patrulhar
		        if (distancia > distanciaVisao + 100)
		            estadoPedinte = INIMIGO_PATRULHANDO;
		        break;
		
		    case INIMIGO_PATRULHANDO:
		        // Se voltar a ver o jogador -> levantar de novo
		        if (distancia < distanciaVisao)
		            estadoPedinte = INIMIGO_ANDANDO;
		        break;
		}


        /* ----------- COMPORTAMENTO DE ANIMAÇÃO ----------- */
        if (estadoPedinte == INIMIGO_LEVANTANDO) {
            if (agora - ultimoFramePedinte > intervaloFramePedinte) {
                ultimoFramePedinte = agora;
                if (framePedinte < 5) framePedinte++;
                else estadoPedinte = INIMIGO_ANDANDO;
            }
            fPedinte = (SDL_Rect){210 * framePedinte, 0, 210, 170};
        }

        else if (estadoPedinte == INIMIGO_ANDANDO) {
            dirPedinte = (player.x < pedinte.x) ? ESQUERDA : DIREITA;
            pedinte.x += (dirPedinte == DIREITA) ? 2 : -2;

            if (agora - ultimoFramePedinte > intervaloFramePedinte) {
                ultimoFramePedinte = agora;
                framePedinte++;
                if (framePedinte > 6) framePedinte = 0;
            }

            int linha = (dirPedinte == DIREITA) ? 2 : 1;
            fPedinte = (SDL_Rect){210 * framePedinte, 170 * linha, 210, 170};
        }

        else if (estadoPedinte == INIMIGO_PATRULHANDO) {
            pedinte.x += (dirPedinte == DIREITA) ? 2 : -2;
            if (pedinte.x < limiteEsq) dirPedinte = DIREITA;
            if (pedinte.x + pedinte.w > limiteDir) dirPedinte = ESQUERDA;

            if (agora - ultimoFramePedinte > intervaloFramePedinte) {
                ultimoFramePedinte = agora;
                framePedinte++;
                if (framePedinte > 6) framePedinte = 0;
            }

            int linha = (dirPedinte == DIREITA) ? 2 : 1;
            fPedinte = (SDL_Rect){210 * framePedinte, 170 * linha, 210, 170};
        }
        
        else if (estadoPedinte == INIMIGO_ATACANDO) {
		    // Define a direção do ataque
		    int linha = (dirPedinte == DIREITA) ? 4 : 3; // supondo linha 3 e 4 na spritesheet
		    fPedinte = (SDL_Rect){210 * framePedinte, 178 * linha, 210, 170};
		
		    if (agora - ultimoFramePedinte > intervaloFramePedinte) {
		        ultimoFramePedinte = agora;
		        framePedinte++;
		        if (framePedinte > 4) { // limite de frames do ataque
		            framePedinte = 0;
		            estadoPedinte = INIMIGO_ANDANDO; // volta a andar
		            atacando = 0; // desativa hitbox
		        }
		    }
		
		    // Atualiza posição da hitbox baseada na direção
		    if (dirPedinte == DIREITA)
		        hitboxPedinte = (SDL_Rect){ pedinte.x + pedinte.w, pedinte.y + 30, 60, 40 };
		    else
		        hitboxPedinte = (SDL_Rect){ pedinte.x - 60, pedinte.y + 30, 60, 40 };
		}


        else if (estadoPedinte == INIMIGO_PARADO) {
    		// Fica completamente imóvel, sem animar
		    framePedinte = 0;
		    fPedinte = (SDL_Rect){0, 0, 210, 170};
		}

    }

    /* FINALIZAÇÃO */
    SDL_DestroyTexture(texFlor);
    SDL_DestroyTexture(texFundo);
    SDL_DestroyTexture(texPlayer);
    SDL_DestroyTexture(texPedinte);
    SDL_DestroyTexture(texPonte);
    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(win);
    SDL_Quit();
    return 0;
}
