#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <assert.h>

int main (int argc, char* args[])
{
    /* INICIALIZAÇÃO */
    SDL_Init(SDL_INIT_EVERYTHING);
    IMG_Init(0);
    SDL_Window* win = SDL_CreateWindow("Game v0.1",
                         SDL_WINDOWPOS_UNDEFINED,
                         SDL_WINDOWPOS_UNDEFINED,
                         0, 0,
                         SDL_WINDOW_FULLSCREEN_DESKTOP);
    SDL_Renderer* ren = SDL_CreateRenderer(win, -1, 0);
    SDL_Texture* sprites = IMG_LoadTexture(ren, "ss.png");
    SDL_Texture* ponte = IMG_LoadTexture(ren, "ponte.png");
    SDL_Texture* fundo = IMG_LoadTexture(ren, "bg+lua.png");
    SDL_Texture* hud = IMG_LoadTexture(ren, "hud.png");
    SDL_Texture* parafu = IMG_LoadTexture(ren, "paralax fundo.png");
    SDL_Texture* parafr = IMG_LoadTexture(ren, "paralax frente.png");
    assert(ponte && sprites && fundo && hud && parafu && parafr);
    
    int w, h;
    SDL_GetWindowSize(win, &w, &h);
    printf("largura: %d, altura: %d \n", w, h);

    SDL_EventState(SDL_MOUSEMOTION, SDL_IGNORE);
    SDL_EventState(SDL_MOUSEBUTTONDOWN, SDL_IGNORE);
    SDL_EventState(SDL_MOUSEBUTTONUP, SDL_IGNORE);

    /* EXECUÇÃO */
    SDL_Rect mapa = { 0, 0 , w, h };
    SDL_Rect parafun = { 0, 0 , w, h };
    SDL_Rect parafre = { 0, 0 , w, h };
    SDL_Rect vida = { 0, 0 , 510, 85 };
    
    SDL_Rect player = { w/5, (h - ((15*h)/100)/3) - 100 +5, 110, 100 }; // já acima do chão invisível
    SDL_Rect ponteR = {0, h-((15*h)/100), w, (15*h)/100};
    
    // Chão invisível (1/3 da altura da ponte)
    SDL_Rect chaoR = {
        0,
        (h - ((15*h)/100)/3)+5,
        w,
        ((15*h)/100)/3
    };

    // frame inicial (primeiro da linha 0, coluna 0)
    SDL_Rect f = {0,0,230,210};

    int espera = 16;
    int vely = 0;
    int gravidade = 1;
    int puloInicial = -18;
    int noChao = 1;

    int direita = 1;
    int esquerda = -1;
    int frameAtual = direita; // começa olhando direita
    Uint32 ultimoFrameTroca = 0;
    int intervaloFrame = 120;
    int frameID = 0;
    int frameIE = 0;

    // Controle da virada
    int virando = 0;       // 1 se direita→esquerda, 2 se esquerda→direita
    int frameVirada = 0;

    int numPlataformas = 2;
    SDL_Rect plataformas[2] = {
        { 200, h-200, 150,20 },
        { 400, h-300, 150,20 },
    };

    while (!SDL_QuitRequested()) {
        // --- RENDERIZAÇÃO ---
        SDL_RenderCopy(ren, fundo ,NULL, &mapa);
        SDL_RenderCopy(ren, parafu ,NULL, &parafun);
        SDL_RenderCopy(ren, parafr ,NULL, &parafre);
        SDL_RenderCopy(ren, hud ,NULL, &vida);
        
        SDL_SetRenderDrawColor(ren, 0x80,0x80,0x80,0x00);
        for (int i=0; i<numPlataformas; i++) {
            SDL_RenderFillRect(ren, &plataformas[i]);
        }

        SDL_RenderCopy(ren, sprites, &f, &player);
        SDL_RenderCopy(ren , ponte ,NULL, &ponteR);

        SDL_RenderPresent(ren);

        // EVENTOS
        SDL_Event evt;
        int isevt = SDL_WaitEventTimeout(&evt, espera);
        if (isevt && evt.type == SDL_QUIT) break;

        // TECLADO
        const Uint8 *keys = SDL_GetKeyboardState(NULL);
        Uint32 agora = SDL_GetTicks();

        // Pulo
        if (keys[SDL_SCANCODE_Z] && noChao) {
            vely = puloInicial;
            noChao = 0;
        }

        int movendo = 0; // flag pra detectar se está andando

        // Movimento lateral ESQUERDA
        if (keys[SDL_SCANCODE_LEFT]) {
            movendo = 1;
            if (frameAtual == direita && !virando) { virando = 1; frameVirada = 0; ultimoFrameTroca = agora; }
            player.x -= 13;
            if (virando == 1) {
                if (agora - ultimoFrameTroca > intervaloFrame) {
                    ultimoFrameTroca = agora;
                    frameVirada++;
                    if (frameVirada > 2) {
                        virando = 0;
                        frameIE = 0;
                        frameAtual = esquerda;
                        f = (SDL_Rect){ 0, 210*2, 230, 210 }; // parado esquerda
                    }
                }
                f = (SDL_Rect){ 230 * frameVirada, 210 * 1, 230, 210 }; // linha 2
            } else {
                frameAtual = esquerda;
                if (agora - ultimoFrameTroca > intervaloFrame) {
                    ultimoFrameTroca = agora;
                    frameIE++;
                    if (frameIE > 3) frameIE = 0;
                }
                f = (SDL_Rect){ 230 * frameIE, 210 * 2, 230, 210 }; // linha 3
            }
        }

        // Movimento lateral DIREITA
        if (keys[SDL_SCANCODE_RIGHT]) {
            movendo = 1;
            if (frameAtual == esquerda && !virando) { virando = 2; frameVirada = 0; ultimoFrameTroca = agora; }
            player.x += 13;
            if (virando == 2) {
                if (agora - ultimoFrameTroca > intervaloFrame) {
                    ultimoFrameTroca = agora;
                    frameVirada++;
                    if (frameVirada > 2) {
                        virando = 0;
                        frameID = 0;
                        frameAtual = direita;
                        f = (SDL_Rect){ 0, 0, 230, 210 }; // parado direita
                    }
                }
                f = (SDL_Rect){ 230 * frameVirada, 210 * 3, 230, 210 }; // linha 4
            } else {
                frameAtual = direita;
                if (agora - ultimoFrameTroca > intervaloFrame) {
                    ultimoFrameTroca = agora;
                    frameID++;
                    if (frameID > 3) frameID = 0;
                }
                f = (SDL_Rect){ 230 * frameID, 210 * 0, 230, 210 }; // linha 1
            }
        }

        // Parado
        if (!movendo && !virando) {
            if (frameAtual == direita) f = (SDL_Rect){0, 0, 230, 210};
            else if (frameAtual == esquerda) f = (SDL_Rect){0, 210*2, 230, 210};
        }

        // GRAVIDADE
        player.y += vely;
        vely += gravidade;
        noChao = 0;

        // COLISÃO com chão invisível
        if (player.y + player.h >= chaoR.y) {
            player.y = chaoR.y - player.h;
            vely = 0;
            noChao = 1;
        }

        // COLISÃO com plataformas (por cima)
        for (int i=0; i<numPlataformas; i++) {
            SDL_Rect plat = plataformas[i];
            if (vely >= 0 &&
                player.y + player.h > plat.y &&
                player.y + player.h - vely <= plat.y &&
                player.x + player.w > plat.x &&
                player.x < plat.x + plat.w)
            {
                player.y = plat.y - player.h;
                vely = 0;
                noChao = 1;
            }
        }

        // COLISÃO por baixo (bateu cabeça)
        for (int i=0; i<numPlataformas; i++) {
            SDL_Rect plat = plataformas[i];
            if (vely < 0 &&
                player.y <= plat.y + plat.h &&
                player.y - vely >= plat.y + plat.h &&
                player.x + player.w > plat.x &&
                player.x < plat.x + plat.w)
            {
                player.y = plat.y + plat.h;
                vely = 0;
            }
        }
    }

    SDL_DestroyTexture(fundo);
    SDL_DestroyTexture(sprites);
    SDL_DestroyTexture(ponte);
    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(win);
    SDL_Quit();
}